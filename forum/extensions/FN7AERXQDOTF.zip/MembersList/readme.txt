Copy the MembersList folder to your Extensions folder
Enable the extension in your Vanilla Settings page
Add the permission to see the new page for each user you want, in your Roles & Permissions settings